package com.cg.ecdm.dao;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.ecdm.exceptions.ECMException;
import com.cg.ecdm.models.ClaimBean;

@Repository
public class ClaimDaoImpl implements IClaimDao {

	@Autowired
	MongoTemplate template;

	
	
	/*
	 * * Description : DAO Layer for Add  Claim Selection Screen Functionality: This
	 * is a Jsp, which will show the selection criteria for claim Job Selection.
	 * 
	 * Restrictions: EG PROPRIETARY INFORMATION, FOR EG USE ONLY Creation date:
	 * (04/12/02) Modifications: Author: Date: Change Description:
	 * Author_Initials 11-12-2018 Initial Version
	 */

	@Override
	public ClaimBean addClaimDetails(ClaimBean claim) {
		claim.setClaimCode(autoGenerate());

		template.insert(claim);
		return claim;
	}

	
	/*
	 * * Description : DAO Layer for View By ID Claim Selection Screen Functionality: This
	 * is a Jsp, which will show the selection criteria for claim Job Selection.
	 * 
	 * Restrictions: EG PROPRIETARY INFORMATION, FOR EG USE ONLY Creation date:
	 * (04/12/02) Modifications: Author: Date: Change Description:
	 * Author_Initials 11-12-2018 Initial Version
	 */
	@Override
	public ClaimBean getById(int claimCode) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(claimCode));
		if (template.findOne(query, ClaimBean.class) == null) {
			try {
				throw new ECMException("No such Id exists " + claimCode);
			} catch (ECMException e) {
				e.printStackTrace();
			}
		}
		return template.findOne(query, ClaimBean.class);
	}


	public static int autoGenerate() {
		Random rand = new Random();
		int generatedNum = 100000 + rand.nextInt(900000);
		return generatedNum;
	} 
	
	
	/*
	 * * Description : DAO Layer for Delete Claim Selection Screen Functionality: This
	 * is a Jsp, which will show the selection criteria for claim Job Selection.
	 * 
	 * Restrictions: EG PROPRIETARY INFORMATION, FOR EG USE ONLY Creation date:
	 * (04/12/02) Modifications: Author: Date: Change Description:
	 * Author_Initials 11-12-2018 Initial Version
	 */
	@Override
	public void deleteClaim(ClaimBean bean) {
		Query query = new Query();
		System.out.println(bean.getClaimCode());
		query.addCriteria(Criteria.where("_id").is(bean.getClaimCode()));
		ClaimBean bean2 = template.findOne(query, ClaimBean.class);
		if (bean2 == null) {
			try {
				throw new ECMException("No such Id exists to delete"
						+ bean.getClaimCode());
			} catch (ECMException e) {
				e.printStackTrace();
			}
		}
		template.remove(bean2);
	}
	
	/*
	 * * Description : DAO Layer for Update Claim Selection Screen Functionality: This
	 * is a Jsp, which will show the selection criteria for claim Job Selection.
	 * 
	 * Restrictions: EG PROPRIETARY INFORMATION, FOR EG USE ONLY Creation date:
	 * (04/12/02) Modifications: Author: Date: Change Description:
	 * Author_Initials 11-12-2018 Initial Version
	 */

	@Override
	public ClaimBean updateClaimDetails(ClaimBean bean) {
		ClaimBean bean2 = getById(bean.getClaimCode());
		ClaimBean bean3 = new ClaimBean();
		if (bean2 != null) {
			bean3 = template.save(bean);
		}
		return bean3;
	}

}
