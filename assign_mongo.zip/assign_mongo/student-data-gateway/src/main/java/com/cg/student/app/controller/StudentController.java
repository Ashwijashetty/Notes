package com.cg.student.app.controller;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.student.app.dto.Student;

@RestController
public class StudentController {
	@RequestMapping(value = "/createData", method = RequestMethod.POST)
	@ResponseBody
	public Student createStudentData(@RequestBody Student student) {
		final String uri = "http://localhost:8083/mongo/student/create"; 
		  
		  RestTemplate restTemplate = new RestTemplate();
			    
		Student result = restTemplate.postForObject( uri, student, Student.class);
			   
		 System.out.println(result);
			    return result;

	}
	
	@RequestMapping(value = "/readData", method = RequestMethod.GET)
	@ResponseBody
	public List<Student> readStudentData() {
		final String uri = "http://localhost:8083/mongo/student/read"; 
		   
		 RestTemplate restTemplate = new RestTemplate();
			    
		List<Student> result = restTemplate.getForObject(uri, List.class);
			  
		  System.out.println(result.size());
			    return result;

	}
/*	@RequestMapping(value="/delete",method=RequestMethod.DELETE)
	@ResponseBody
	public void deleteStudent(){
		final String uri="http://localhost:8083/mongo/student/delete/5bff58da399c2732949aa13f";
		RestTemplate restTemplate=new RestTemplate();
	     restTemplate.delete(uri);
	}
	
	@RequestMapping(value="/update",method=RequestMethod.PUT)
	@ResponseBody
	public void updateStudent(@RequestBody Student student){
		final String uri="http://localhost:8083/mongo/student/update/5bff56f1399c2732949aa13d";
		RestTemplate restTemplate=new RestTemplate();
		 restTemplate.put( uri, student,Student.class);
	
	}*/
	@RequestMapping(value="/update/{id}",method=RequestMethod.PUT)
	@ResponseBody
	public void updateStudent(@PathVariable("id")ObjectId id,@RequestBody Student student){
		System.out.println(id);
		student.set_id(id);
		final String uri="http://localhost:8083/mongo/student/update/{id}";
		RestTemplate restTemplate=new RestTemplate();
	     restTemplate.put(uri, student, id);
	}
	@RequestMapping(value="/delete/{id}",method=RequestMethod.DELETE)
	@ResponseBody
	public void deleteStudent(@PathVariable("id")ObjectId id){
		final String uri="http//localhost:8083/mongo/student/delete/{id}";
		RestTemplate restTemplate=new RestTemplate();
		restTemplate.delete(uri, id);
	}
}
