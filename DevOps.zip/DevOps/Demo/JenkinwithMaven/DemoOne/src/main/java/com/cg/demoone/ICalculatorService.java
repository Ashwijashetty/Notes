package com.cg.demoone;

public interface ICalculatorService {

	public double addition(double numOne,double numTwo);
	public double subTraction(double numOne,double numTwo);
	public double mulTiplication(double numOne,double numTwo);
	public double division(double numOne,double numTwo);
}